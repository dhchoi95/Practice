import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
if (!existsSync('.env')) {
  const password = randomBytes(24).toString('hex');
  const settings = {
    POSTGRES_PASSWORD: password,
    DATABASE_URL: `postgresql://practice:${password}@127.0.0.1:5432/practice`,
    AUTH_SECRET: randomBytes(48).toString('hex'),
    APP_URL: 'http://localhost:3000',
    DEMO_EMAIL: 'owner@burger.local',
    DEMO_PASSWORD: randomBytes(18).toString('hex'),
    DEMO_STAFF_EMAIL: 'staff@burger.local',
    DEMO_STAFF_PASSWORD: randomBytes(18).toString('hex'),
  };
  writeFileSync('.env', Object.entries(settings).map(([key,value]) => `${key}=${value}`).join('\n')+'\n', { mode: 0o600 });
}
function run(command, args) {
  const result = spawnSync(command, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
run('docker',['compose','up','-d','--wait']);
run('npm',['ci']);
for (const command of ['db:generate','db:migrate:deploy','db:seed','build']) run('npm',['run',command]);
console.log('Ready. Start: npm run start -- --hostname 0.0.0.0 --port 3000');
console.log('Open http://localhost:3000; login credentials are in your local .env file.');
