# PC에서 실행하기

1. Node.js 24 LTS와 Docker Desktop을 설치하고 Docker Desktop을 실행합니다.
2. 압축을 바탕화면 AI 폴더에 풀어 `AI/Practice` 폴더를 만듭니다.
3. 이 Practice 폴더에서 터미널을 열고 아래 명령을 실행합니다.

```powershell
node scripts/local-setup.mjs
npm run start -- --hostname 0.0.0.0 --port 3000
```

4. PC 브라우저에서 http://localhost:3000 을 엽니다.
5. Practice 폴더의 `.env` 파일을 메모장으로 열어 DEMO_EMAIL과 DEMO_PASSWORD로 로그인합니다. 직원 계정은 DEMO_STAFF_EMAIL과 DEMO_STAFF_PASSWORD입니다. 비밀번호는 PC에서 처음 실행할 때 무작위로 생성됩니다. .env 파일을 공유하지 마세요.

이 창을 열어 둔 동안 웹이 실행됩니다. 종료는 Ctrl+C입니다. 다음 실행은 `docker compose up -d --wait` 후 위 npm start 명령만 실행하면 됩니다. Docker의 practice_data 볼륨에 업무 기록이 유지됩니다. 포트 5432 또는 3000을 이미 쓰고 있다면 기존 프로그램을 확인해 충돌을 해결하세요.

이 압축에는 완성한 소스, 요구사항·설계·검증 문서, 실제 화면 캡처가 들어 있습니다. 클라우드의 비밀번호와 DB dump는 포함하지 않으며 PC에는 새 데모 매장이 생성됩니다. 클라우드 전용 README/scripts와 달리 이 안내의 local-setup.mjs 및 compose.yaml을 사용하세요. PC용 추가 실행 도구는 정적 구문 검사를 수행했으나 사용자 PC에서의 설치·실행은 아직 확인하지 않았습니다.
